import React, { useState } from 'react';
import { Volume2, CheckCircle2, XCircle, Sparkles } from 'lucide-react';
import { getTtsEngineStatuses, speakEnglishText } from '../lib/speech';
import { getTtsMode, setTtsMode, TtsMode } from '../lib/ttsSettings';

export const VoiceSettingsView: React.FC = () => {
  const [mode, setModeState] = useState<TtsMode>(getTtsMode());
  const [statuses, setStatuses] = useState(getTtsEngineStatuses());
  const [testing, setTesting] = useState<TtsMode | null>(null);

  const choose = (m: TtsMode) => {
    setTtsMode(m);
    setModeState(m);
  };

  const test = async (m: TtsMode) => {
    const prev = getTtsMode();
    setTesting(m);
    setTtsMode(m);
    await speakEnglishText('Hello, this is a test of the voice engine.', 1, 'en-US');
    setTtsMode(prev);
    setTesting(null);
    setStatuses(getTtsEngineStatuses());
  };

  return (
    <div className="max-w-3xl mx-auto p-4 md:p-6 space-y-5" dir="rtl">
      <div className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-700 text-white rounded-3xl p-6 flex items-center justify-between shadow-md">
        <div>
          <h2 className="text-xl font-black text-white">موتور صدا و تلفظ</h2>
          <p className="text-xs text-indigo-100 mt-1.5">انتخاب کنید صدا از کدام موتور پخش شود، و ببینید هرکدام الان در دسترس هست یا نه.</p>
        </div>
        <Volume2 className="w-8 h-8" />
      </div>

      <label className={`block rounded-2xl border-2 p-4 cursor-pointer transition ${mode === 'auto' ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 bg-white'}`}>
        <div className="flex items-center gap-2">
          <input type="radio" checked={mode === 'auto'} onChange={() => choose('auto')} />
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <span className="font-black text-sm">حالت خودکار (پیشنهادی)</span>
        </div>
        <p className="text-xs text-slate-500 mt-1 mr-6">به‌ترتیب امتحان می‌کند: آفلاین اندروید ← آنلاین ابری ← Web Speech ← بوق آخر. همیشه بهترین گزینه‌ی موجود را پیدا می‌کند.</p>
      </label>

      <div className="space-y-3">
        {statuses.map((s) => (
          <label
            key={s.id}
            className={`block rounded-2xl border-2 p-4 cursor-pointer transition ${mode === s.id ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 bg-white'} ${!s.available ? 'opacity-70' : ''}`}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <input type="radio" checked={mode === s.id} onChange={() => choose(s.id)} />
                <span className="font-black text-sm">{s.labelFa}</span>
              </div>
              {s.available ? (
                <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-full">
                  <CheckCircle2 className="w-3.5 h-3.5" /> در دسترس
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-1 rounded-full">
                  <XCircle className="w-3.5 h-3.5" /> غیرفعال
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1 mr-6">{s.descriptionFa}</p>
            {!s.available && s.reasonFa && <p className="text-[11px] text-rose-600 mt-1 mr-6">{s.reasonFa}</p>}
            {s.available && (
              <button
                onClick={(e) => { e.preventDefault(); test(s.id); }}
                disabled={testing !== null}
                className="mt-2 mr-6 text-[11px] font-bold text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-xl disabled:opacity-50"
              >
                {testing === s.id ? 'در حال پخش...' : 'تست صدا'}
              </button>
            )}
          </label>
        ))}
      </div>
    </div>
  );
};
