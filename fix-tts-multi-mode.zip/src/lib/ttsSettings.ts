// Persisted user choice of which TTS engine to use. 'auto' keeps the smart
// cascade (native -> cloud -> web speech -> beep). The others force one
// specific engine so the person can test/compare, or so an advanced user can
// pin a mode deliberately (e.g. always cloud for best quality when online).
export type TtsMode = 'auto' | 'native' | 'cloud' | 'neural' | 'web';

const KEY = 'linguaai.ttsMode';

export function getTtsMode(): TtsMode {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'auto' || v === 'native' || v === 'cloud' || v === 'neural' || v === 'web') return v;
  } catch {
    // ignore
  }
  return 'auto';
}

export function setTtsMode(mode: TtsMode): void {
  try {
    localStorage.setItem(KEY, mode);
  } catch {
    // ignore
  }
}

export interface TtsEngineStatus {
  id: TtsMode;
  labelFa: string;
  descriptionFa: string;
  available: boolean;
  reasonFa?: string; // shown when unavailable
}
