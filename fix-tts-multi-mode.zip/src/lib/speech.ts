import { apiUrl, hasRemoteApi } from './api';
import { getTtsMode, TtsEngineStatus } from './ttsSettings';

export type SupportedAccent = 'en-US' | 'en-GB' | 'en-AU' | 'ar-IQ' | 'ar-LB';

export interface AccentConfig {
  code: SupportedAccent;
  labelFa: string;
  labelEn: string;
  flag: string;
}

export const ACCENT_CONFIGS: AccentConfig[] = [
  { code: 'en-US', labelFa: 'آمریکایی (US)', labelEn: 'American Accent', flag: '🇺🇸' },
  { code: 'en-GB', labelFa: 'بریتانیایی (UK)', labelEn: 'British Accent', flag: '🇬🇧' },
  { code: 'en-AU', labelFa: 'استرالیایی (AU)', labelEn: 'Australian Accent', flag: '🇦🇺' },
  { code: 'ar-IQ', labelFa: 'عراقی (Iraqi)', labelEn: 'Iraqi Dialect', flag: '🇮🇶' },
  { code: 'ar-LB', labelFa: 'لبنانی (Lebanese)', labelEn: 'Lebanese Dialect', flag: '🇱🇧' },
];

let activeAudioFallback: HTMLAudioElement | null = null;

// ============================================================================
// ENGINE 1 — Native Android TTS (offline, works fully on-device, no backend).
// Registered by MainActivity.java's addJavascriptInterface(..., "AndroidTTS").
// This is Android's own built-in TextToSpeech engine (Google TTS or
// whichever engine the person has installed) — good quality, always
// available on a real Android device, requires no network.
// ============================================================================
declare global {
  interface Window {
    AndroidTTS?: {
      speak: (text: string, language: string, rate: number, pitch: number, requestId: string) => void;
      stop: () => void;
      isAvailable: () => boolean;
    };
    __linguaNativeTtsDone?: (requestId: string) => void;
  }
}

let nativeRequestCounter = 0;
const nativeCallbacks = new Map<string, () => void>();

if (typeof window !== 'undefined') {
  window.__linguaNativeTtsDone = (requestId: string) => {
    const cb = nativeCallbacks.get(requestId);
    if (cb) {
      nativeCallbacks.delete(requestId);
      cb();
    }
  };
}

export function hasNativeTts(): boolean {
  try {
    return typeof window !== 'undefined' && !!window.AndroidTTS && window.AndroidTTS.isAvailable();
  } catch {
    return false;
  }
}

function playNativeAndroidTts(text: string, language: string, rate: number, pitch: number): Promise<boolean> {
  return new Promise((resolve) => {
    if (!hasNativeTts()) { resolve(false); return; }
    const requestId = `tts-${Date.now()}-${nativeRequestCounter++}`;
    let settled = false;
    const finish = (ok: boolean) => { if (!settled) { settled = true; resolve(ok); } };
    nativeCallbacks.set(requestId, () => finish(true));
    try {
      window.AndroidTTS!.speak(text, language, rate, pitch, requestId);
    } catch {
      nativeCallbacks.delete(requestId);
      finish(false);
      return;
    }
    setTimeout(() => finish(true), Math.max(4000, text.length * 220));
  });
}

// ============================================================================
// ENGINE 2 — Cloud TTS (online, via your own deployed backend's /api/tts).
// Only usable once VITE_API_BASE_URL points to a real deployed server.ts
// with a cloud TTS provider (Azure/Google/etc.) wired up. This gives the
// highest quality and genuinely native-sounding dialect voices, but needs
// internet and a running backend.
// ============================================================================
function playCloudTts(text: string, langCode: string, rate: number): Promise<boolean> {
  return new Promise((resolve) => {
    if (!hasRemoteApi()) { resolve(false); return; }
    try {
      const audioUrl = apiUrl(`/api/tts?text=${encodeURIComponent(text)}&lang=${encodeURIComponent(langCode)}`);
      const audio = new Audio(audioUrl);
      audio.playbackRate = Math.min(Math.max(rate, 0.75), 1.25);
      activeAudioFallback = audio;
      audio.onended = () => { activeAudioFallback = null; resolve(true); };
      audio.onerror = () => { activeAudioFallback = null; resolve(false); };
      const p = audio.play();
      if (p !== undefined) p.catch(() => { activeAudioFallback = null; resolve(false); });
    } catch {
      resolve(false);
    }
  });
}

// ============================================================================
// ENGINE 3 — Open-source neural offline voices (Habibi-IRQ / Leva-TTS style
// dialect voice packs). NOT FUNCTIONAL YET — this is intentionally honest
// rather than faking success. Real on-device neural TTS needs a proper
// runtime (tokenizer + speaker conditioning + decoder, not just a .onnx
// file), which is a separate engineering effort from wiring the UI. The
// native Android bridge (LinguaVoicePackManager.synthesize) already reports
// this accurately as "local-neural-runtime-not-installed" — we surface that
// same honesty here instead of silently falling through to a beep.
// ============================================================================
export function hasNeuralVoicePack(): boolean {
  // Flip this on once a real on-device runtime + installed pack exists.
  return false;
}

// ============================================================================
// ENGINE 4 — Browser Web Speech API (SpeechSynthesis). Unreliable inside
// Android WebViews specifically (often silent), but works fine in a normal
// desktop/mobile browser tab if you ever run this as a web app.
// ============================================================================
let cachedVoices: SpeechSynthesisVoice[] = [];

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  const loadVoices = () => {
    try { cachedVoices = window.speechSynthesis.getVoices(); } catch { /* ignore */ }
  };
  loadVoices();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }
}

export function hasWebSpeech(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

function playWebSpeech(text: string, langCode: string, rate: number, pitch: number, gender: 'male' | 'female'): Promise<boolean> {
  return new Promise((resolve) => {
    if (!hasWebSpeech()) { resolve(false); return; }
    try {
      if (window.speechSynthesis.paused) window.speechSynthesis.resume();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = langCode;
      utterance.rate = Math.min(Math.max(rate, 0.6), 1.4);
      utterance.pitch = gender === 'male'
        ? Math.max(0.7, Math.min(pitch * 0.85, 0.95))
        : Math.min(1.3, Math.max(pitch * 1.05, 1.0));

      const voices = cachedVoices.length > 0 ? cachedVoices : window.speechSynthesis.getVoices();
      const prefix = langCode.slice(0, 2);
      const match = voices.filter(
        (v) => v.lang === langCode || v.lang.replace('_', '-') === langCode || v.lang.toLowerCase().startsWith(prefix.toLowerCase())
      );
      if (match.length > 0) utterance.voice = match[0];

      let done = false;
      utterance.onend = () => { if (!done) { done = true; resolve(true); } };
      utterance.onerror = () => { if (!done) { done = true; resolve(false); } };
      window.speechSynthesis.speak(utterance);
      setTimeout(() => { if (!done) { done = true; resolve(true); } }, Math.max(3000, text.length * 200));
    } catch {
      resolve(false);
    }
  });
}

// Last-resort audible cue so a tap never feels completely dead even when
// every real engine has failed (e.g. emulator with no TTS engine at all).
function playBeepFallback(): void {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  } catch {
    // ignore
  }
}

// ---- Status for the settings UI ----
export function getTtsEngineStatuses(): TtsEngineStatus[] {
  return [
    {
      id: 'native',
      labelFa: 'آفلاین — TTS داخلی اندروید',
      descriptionFa: 'موتور Text-to-Speech خود گوشی (مثل Google TTS)، کاملاً بدون اینترنت.',
      available: hasNativeTts(),
      reasonFa: hasNativeTts() ? undefined : 'روی این دستگاه/مرورگر در دسترس نیست (فقط داخل اپ نصب‌شده اندروید کار می‌کند).',
    },
    {
      id: 'cloud',
      labelFa: 'آنلاین — TTS ابری با کیفیت بالا',
      descriptionFa: 'صدای طبیعی از طریق سرور خودتان (Azure/Google) — نیاز به اینترنت و بک‌اند دیپلوی‌شده.',
      available: hasRemoteApi(),
      reasonFa: hasRemoteApi() ? undefined : 'آدرس بک‌اند (VITE_API_BASE_URL) تنظیم نشده است.',
    },
    {
      id: 'neural',
      labelFa: 'آفلاین متن‌باز — صدای طبیعی لهجه (Habibi/Leva)',
      descriptionFa: 'مدل عصبی متن‌باز مخصوص لهجه عراقی/لبنانی، کاملاً روی گوشی.',
      available: hasNeuralVoicePack(),
      reasonFa: 'هنوز راه‌اندازی نشده — نیاز به توسعه‌ی جداگانه‌ی runtime روی دستگاه دارد.',
    },
    {
      id: 'web',
      labelFa: 'آفلاین — Web Speech مرورگر',
      descriptionFa: 'موتور صدای مرورگر. داخل اپ اندروید معمولاً بی‌صداست؛ بیشتر برای نسخه‌ی وب مفید است.',
      available: hasWebSpeech(),
      reasonFa: hasWebSpeech() ? undefined : 'مرورگر از Web Speech API پشتیبانی نمی‌کند.',
    },
  ];
}

export function stopSpeech(): void {
  if (hasNativeTts()) {
    try { window.AndroidTTS!.stop(); } catch { /* ignore */ }
  }
  if (hasWebSpeech()) {
    try { window.speechSynthesis.cancel(); } catch { /* ignore */ }
  }
  if (activeAudioFallback) {
    try { activeAudioFallback.pause(); activeAudioFallback = null; } catch { /* ignore */ }
  }
}

export async function speakEnglishText(
  text: string,
  rate: number = 1.0,
  accent: SupportedAccent = 'en-US',
  pitch: number = 1.0,
  gender: 'male' | 'female' = 'female'
): Promise<void> {
  if (!text || !text.trim()) return;
  stopSpeech();

  const cleanText = text.trim();
  const langCode = accent === 'ar-IQ' || accent === 'ar-LB' ? 'ar' : accent;
  const mode = getTtsMode();

  if (mode === 'native') {
    await playNativeAndroidTts(cleanText, langCode, rate, pitch);
    return; // explicit mode: don't silently switch engines if it fails
  }
  if (mode === 'cloud') {
    await playCloudTts(cleanText, langCode, rate);
    return;
  }
  if (mode === 'neural') {
    // Honest no-op: this engine isn't functional yet. No beep, no fake
    // success — surfacing that clearly is better than pretending it worked.
    return;
  }
  if (mode === 'web') {
    await playWebSpeech(cleanText, langCode, rate, pitch, gender);
    return;
  }

  // mode === 'auto': smart cascade, most-reliable-offline first.
  if (await playNativeAndroidTts(cleanText, langCode, rate, pitch)) return;
  if (await playCloudTts(cleanText, langCode, rate)) return;
  if (await playWebSpeech(cleanText, langCode, rate, pitch, gender)) return;
  playBeepFallback();
}
