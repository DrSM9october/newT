export type SupportedAccent = 'en-US' | 'en-GB' | 'en-AU' | 'ar-IQ' | 'ar-LB';
export type SpeechMode = 'auto' | 'native' | 'online';

export interface AccentConfig {
  code: SupportedAccent;
  labelFa: string;
  labelEn: string;
  flag: string;
}

export const ACCENT_CONFIGS: AccentConfig[] = [
  { code: 'en-US', labelFa: 'آمریکایی (US)', labelEn: 'American Accent', flag: '🇺🇸' },
  { code: 'en-GB', labelFa: 'بریتانیایی (UK)', labelEn: 'British Accent', flag: '🇬🇧' },
  { code: 'en-AU', labelFa: 'استرالیایی (AU)', labelEn: 'Australian Accent', flag: '🇦🇺' },
  { code: 'ar-IQ', labelFa: 'عراقی (Iraqi)', labelEn: 'Iraqi Dialect', flag: '🇮🇶' },
  { code: 'ar-LB', labelFa: 'لبنانی (Lebanese)', labelEn: 'Lebanese Dialect', flag: '🇱🇧' },
];

declare global {
  interface Window {
    AndroidTTS?: {
      speak: (text: string, language: string, rate: number, pitch: number, requestId: string) => void;
      speakOnline?: (text: string, language: string, rate: number, requestId: string) => void;
      stop: () => void;
      stopOnline?: () => void;
      isAvailable: () => boolean;
    };
    __linguaNativeTtsDone?: (requestId: string) => void;
    __linguaNativeTtsError?: (requestId: string, message: string) => void;
    __linguaOnlineTtsDone?: (requestId: string) => void;
    __linguaOnlineTtsError?: (requestId: string, message: string) => void;
  }
}

let activeAudio: HTMLAudioElement | null = null;
let requestCounter = 0;
const getRequestId = () => `tts-${Date.now()}-${++requestCounter}`;

export function getSpeechMode(): SpeechMode {
  if (typeof window === 'undefined') return 'auto';
  const value = window.localStorage.getItem('linguaai-speech-mode');
  return value === 'native' || value === 'online' || value === 'auto' ? value : 'auto';
}

export function setSpeechMode(mode: SpeechMode): void {
  if (typeof window !== 'undefined') window.localStorage.setItem('linguaai-speech-mode', mode);
}

export function isNativeTtsAvailable(): boolean {
  try {
    return typeof window !== 'undefined' &&
      !!window.AndroidTTS &&
      !!window.AndroidTTS.isAvailable &&
      window.AndroidTTS.isAvailable();
  } catch {
    return false;
  }
}

export function stopSpeech(): void {
  try { window.speechSynthesis?.cancel(); } catch {}
  try { window.AndroidTTS?.stop?.(); } catch {}
  try { window.AndroidTTS?.stopOnline?.(); } catch {}
  if (activeAudio) {
    try { activeAudio.pause(); activeAudio.src = ''; } catch {}
    activeAudio = null;
  }
}

function languageForOnline(accent: SupportedAccent): string {
  if (accent === 'ar-IQ' || accent === 'ar-LB') return 'ar';
  return accent.startsWith('en') ? 'en' : 'en';
}

function webSpeech(text: string, rate: number, accent: SupportedAccent, pitch: number, gender: 'male' | 'female'): Promise<void> {
  return new Promise(resolve => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return resolve();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = accent;
    u.rate = Math.min(Math.max(rate, 0.6), 1.4);
    u.pitch = gender === 'male' ? Math.max(0.7, Math.min(pitch * 0.85, 0.95)) : Math.min(1.3, Math.max(pitch * 1.05, 1));
    let finished = false;
    const done = () => { if (!finished) { finished = true; resolve(); } };
    u.onend = done;
    u.onerror = done;
    try { window.speechSynthesis.speak(u); } catch { done(); }
    window.setTimeout(done, Math.max(4000, text.length * 220));
  });
}

function nativeSpeech(text: string, rate: number, accent: SupportedAccent, pitch: number): Promise<void> {
  return new Promise(resolve => {
    if (!isNativeTtsAvailable()) return resolve();
    const id = getRequestId();
    const previousDone = window.__linguaNativeTtsDone;
    const previousError = window.__linguaNativeTtsError;
    let finished = false;
    const cleanup = () => {
      if (window.__linguaNativeTtsDone === done) window.__linguaNativeTtsDone = previousDone;
      if (window.__linguaNativeTtsError === error) window.__linguaNativeTtsError = previousError;
    };
    const done = (requestId: string) => {
      if (requestId !== id || finished) return;
      finished = true; cleanup(); resolve();
    };
    const error = (requestId: string) => {
      if (requestId !== id || finished) return;
      finished = true; cleanup(); resolve();
    };
    window.__linguaNativeTtsDone = done;
    window.__linguaNativeTtsError = error;
    try {
      window.AndroidTTS!.speak(text, accent, Math.min(Math.max(rate, 0.5), 2), Math.min(Math.max(pitch, 0.5), 2), id);
    } catch { error(id, 'native-call-failed'); }
    window.setTimeout(() => error(id, 'native-timeout'), Math.max(8000, text.length * 350));
  });
}

function onlineNativeSpeech(text: string, rate: number, accent: SupportedAccent): Promise<boolean> {
  return new Promise(resolve => {
    if (typeof window === 'undefined' || !window.AndroidTTS?.speakOnline || !navigator.onLine) return resolve(false);
    const id = getRequestId();
    let finished = false;
    const oldDone = window.__linguaOnlineTtsDone;
    const oldError = window.__linguaOnlineTtsError;
    const cleanup = () => {
      if (window.__linguaOnlineTtsDone === done) window.__linguaOnlineTtsDone = oldDone;
      if (window.__linguaOnlineTtsError === error) window.__linguaOnlineTtsError = oldError;
    };
    const done = (requestId: string) => {
      if (requestId !== id || finished) return;
      finished = true; cleanup(); resolve(true);
    };
    const error = (requestId: string) => {
      if (requestId !== id || finished) return;
      finished = true; cleanup(); resolve(false);
    };
    window.__linguaOnlineTtsDone = done;
    window.__linguaOnlineTtsError = error;
    try {
      window.AndroidTTS.speakOnline(text.slice(0, 300), languageForOnline(accent), Math.min(Math.max(rate, 0.75), 1.25), id);
    } catch { error(id, 'online-call-failed'); }
    window.setTimeout(() => error(id, 'online-timeout'), Math.max(10000, text.length * 450));
  });
}

function onlineWebSpeech(text: string, rate: number, accent: SupportedAccent): Promise<boolean> {
  return new Promise(resolve => {
    if (typeof window === 'undefined' || !navigator.onLine) return resolve(false);
    const lang = languageForOnline(accent);
    try {
      const audio = new Audio(`/api/tts?text=${encodeURIComponent(text.slice(0, 300))}&lang=${encodeURIComponent(lang)}`);
      audio.playbackRate = Math.min(Math.max(rate, 0.75), 1.25);
      activeAudio = audio;
      let finished = false;
      const finish = (ok: boolean) => {
        if (finished) return;
        finished = true;
        if (activeAudio === audio) activeAudio = null;
        resolve(ok);
      };
      audio.onended = () => finish(true);
      audio.onerror = () => finish(false);
      const p = audio.play();
      p?.catch(() => finish(false));
    } catch { resolve(false); }
  });
}

export async function speakEnglishText(
  text: string,
  rate = 1.0,
  accent: SupportedAccent = 'en-US',
  pitch = 1.0,
  gender: 'male' | 'female' = 'female'
): Promise<void> {
  const cleanText = text?.trim();
  if (!cleanText) return;

  stopSpeech();
  const mode = getSpeechMode();

  // Android APK: use a real native online engine first, then native offline.
  if (mode === 'online' || mode === 'auto') {
    if (await onlineNativeSpeech(cleanText, rate, accent)) return;
    if (mode === 'online') {
      if (await onlineWebSpeech(cleanText, rate, accent)) return;
      // Online mode intentionally falls back to native so the app never becomes silent.
    }
  }

  if (mode === 'native' || mode === 'auto' || isNativeTtsAvailable()) {
    if (isNativeTtsAvailable()) {
      await nativeSpeech(cleanText, rate, accent, pitch);
      return;
    }
  }

  // Browser/PWA fallback. Never emit a fake beep.
  if (mode === 'native') {
    await webSpeech(cleanText, rate, accent, pitch, gender);
    return;
  }

  const playedOnlineWeb = await onlineWebSpeech(cleanText, rate, accent);
  if (!playedOnlineWeb) {
    await webSpeech(cleanText, rate, accent, pitch, gender);
  }
}
