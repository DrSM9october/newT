import { ChatMessage, DialectType, GenderType, DifficultyLevel } from '../types';
import { analyzeOfflineMessage } from '../lib/offlineAnalyzer';
import { apiUrl, hasRemoteApi } from '../lib/api';

export interface ChatExplainRequest {
  userText: string;
  history?: ChatMessage[];
  personaId?: string;
  dialect?: DialectType;
  gender?: GenderType;
  level?: DifficultyLevel;
}

export interface ChatExplainResponse {
  replyEn: string;
  replyFa: string;
  feedback: {
    grammarScore: number;
    correctedSentence?: string;
    explanationFa?: string;
    genderNoteFa?: string;
    betterAlternatives?: string[];
    vocabularyTips?: string[];
    persianTranslation?: string;
  };
  providerUsed: string;
}

export class AIManager {
  public async sendChatMessage(req: ChatExplainRequest): Promise<ChatExplainResponse> {
    if (!hasRemoteApi()) {
      // No backend configured at build time — go straight to the offline
      // engine instead of wasting time on a request that can never succeed.
      const offlineRes = analyzeOfflineMessage(req.userText, req.personaId || 'alex_casual', req.dialect || 'en-US');
      return {
        replyEn: offlineRes.replyEn,
        replyFa: offlineRes.replyFa,
        feedback: {
          grammarScore: offlineRes.grammarScore,
          correctedSentence: offlineRes.correctedSentence,
          explanationFa: offlineRes.explanationFa,
          betterAlternatives: offlineRes.betterAlternatives,
          vocabularyTips: offlineRes.vocabularyTips,
          persianTranslation: offlineRes.replyFa,
        },
        providerUsed: 'offline_nlp_engine',
      };
    }
    try {
      const response = await fetch(apiUrl('/api/chat-explain'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userText: req.userText,
          history: req.history,
          personaId: req.personaId,
          dialect: req.dialect,
          userGender: req.gender,
          userLevel: req.level,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const payload = data.data || data;

      return {
        replyEn: payload.replyEn || '',
        replyFa: payload.replyFa || '',
        feedback: {
          grammarScore: payload.grammarScore ?? 90,
          correctedSentence: payload.correctedSentence || undefined,
          explanationFa: payload.explanationFa || undefined,
          genderNoteFa: payload.genderNoteFa || undefined,
          betterAlternatives: payload.betterAlternatives || [],
          vocabularyTips: payload.vocabHighlights
            ? payload.vocabHighlights.map((v: any) => `${v.word}: ${v.meaningFa}`)
            : [],
          persianTranslation: payload.replyFa || '',
        },
        providerUsed: 'gemini_cloud',
      };
    } catch (err: any) {
      console.warn('Using offline NLP analyzer in AIManager:', err);
      const offlineRes = analyzeOfflineMessage(
        req.userText,
        req.personaId || 'alex_casual',
        req.dialect || 'en-US'
      );

      return {
        replyEn: offlineRes.replyEn,
        replyFa: offlineRes.replyFa,
        feedback: {
          grammarScore: offlineRes.grammarScore,
          correctedSentence: offlineRes.correctedSentence,
          explanationFa: offlineRes.explanationFa,
          betterAlternatives: offlineRes.betterAlternatives,
          vocabularyTips: offlineRes.vocabularyTips,
          persianTranslation: offlineRes.replyFa,
        },
        providerUsed: 'offline_nlp_engine',
      };
    }
  }

  public async sendScenarioMessage(req: {
    userText: string;
    history: any[];
    persona: any;
    dialect?: DialectType;
    gender?: GenderType;
    level?: DifficultyLevel;
  }) {
    if (!hasRemoteApi()) {
      const offlineRes = analyzeOfflineMessage(req.userText, req.persona?.id || 'alex_casual', req.dialect || 'en-US');
      return {
        replyEn: offlineRes.replyEn,
        replyFa: offlineRes.replyFa,
        grammarScore: offlineRes.grammarScore,
        correctedSentence: offlineRes.correctedSentence,
        explanationFa: offlineRes.explanationFa,
        betterAlternatives: offlineRes.betterAlternatives,
      };
    }
    try {
      const response = await fetch(apiUrl('/api/scenario-chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userText: req.userText,
          history: req.history,
          persona: req.persona,
          dialect: req.dialect,
          userGender: req.gender,
          userLevel: req.level,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      return data.data || data;
    } catch (err) {
      console.warn('Fallback in scenario chat:', err);
      const offlineRes = analyzeOfflineMessage(
        req.userText,
        req.persona?.id || 'alex_casual',
        req.dialect || 'en-US'
      );

      return {
        replyEn: offlineRes.replyEn,
        replyFa: offlineRes.replyFa,
        grammarScore: offlineRes.grammarScore,
        correctedSentence: offlineRes.correctedSentence,
        explanationFa: offlineRes.explanationFa,
        betterAlternatives: offlineRes.betterAlternatives,
      };
    }
  }
}

export const aiManager = new AIManager();

