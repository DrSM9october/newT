// The Android APK has no bundled server — /api/* requests must go to a real,
// deployed backend (server.ts hosted somewhere reachable over HTTPS).
// VITE_API_BASE_URL is baked in at BUILD time by Vite (not runtime), so it
// must be set in the environment before running `npm run build` for Android.
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').trim().replace(/\/$/, '');

export function apiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  return `${API_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

// True only when a backend URL was actually configured at build time.
// When false, the app is offline-only by design (no Gemini, no cloud TTS) —
// this is expected on a standalone APK with no deployed backend.
export function hasRemoteApi(): boolean {
  return Boolean(API_BASE_URL);
}
